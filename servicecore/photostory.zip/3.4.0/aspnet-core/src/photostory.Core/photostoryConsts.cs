﻿namespace photostory
{
    public class photostoryConsts
    {
        public const string LocalizationSourceName = "photostory";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
